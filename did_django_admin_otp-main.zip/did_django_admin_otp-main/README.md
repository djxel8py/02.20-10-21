# did_django_admin_otp
Django project thats add one time passwords to Django admin

1) cd to development directory
2) mkvirtualenv did_django_admin_otp
3) mkdir did_django_admin_otp
4) clone repository to new directory
5) pip install -r requirements.txt
6) python manage.py makemigrations
7) python manage.py migrate
8) python manage.py runserver
9) https://localhost:8000/django_admin
10) set up a new OTP user
11) scan QR code in authenticator App
12) https://localhost:8000/admin

13) Bob's you uncle!

