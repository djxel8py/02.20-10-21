# did_django_schedule_jobs
Django project that demonstrates how to shchedule job in Django

1) cd to development directory
2) mkvirtualenv did_django_schedule_jobs
3) mkdir did_django_schedule_jobs
4) clone repository to new directory
5) pip install -r requirements.txt

6) python manage.py runserver
7) https://localhost:8000 - Bob's your uncle!! 

