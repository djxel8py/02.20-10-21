# resume_app

Hi there.
This is the a Django app that helps you to digitize your resume.
With any luck, you will stand out in a round and land your dream job
