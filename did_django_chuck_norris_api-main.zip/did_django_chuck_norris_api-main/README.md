# did_django_chuck_norris_api
Django project that demonstrates how to use the Chuck Norris api in a Django project

1) cd to development directory
2) mkvirtualenv did_django_schedule_jobs
3) mkdir did_django_schedule_jobs
4) clone repository to new directory
5) pip install -r requirements.txt
6) add api key in settings.ini file

API_KEY = 'XXX'

6) python manage.py runserver
7) https://localhost:8000 - Bob's your uncle!! 

