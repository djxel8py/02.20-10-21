CAT1 = (
    ('Sell','Sell'),
    ('Rent','Rent'),
)
CAT2 = (
    ('Car','Car'),
    ('RealEstate','RealEstate'),
    ('Phone','Phone'),
)
CAT3 = (
    ('Audi','Audi'),
    ('BMW','BMW'),
    ('Bungalow','Bungalow'),
    ('Apartment','Apartment'),
    ('LG','LG'),
    ('GeneralMobile','GeneralMobile'),
)
COUNTRY = (
    ('America','America'),
    ('England','England'),
    ('Germany','Germany'),
    ('Turkey','Turkey'),
)

CITY = (
    ('NY','NY'),
    ('London','London'),
    ('Berlin','Berlin'),
    ('Ankara','Ankara'),
)

TOU = (
    ('Standart','Standart'),
    ('Bronze','Bronze'),
    ('Gold','Gold'),
    ('VIP','VIP'),
)
