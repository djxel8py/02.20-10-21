# dropzone

this is just a educational page of mine, I try to learn step by step django.
    
admin  : a
pass : 1
