# did_python_hedera_hashgraph_3
Thanks for taking a we look at the code for my Python Hedera hashgraph playlist(https://www.youtube.com/playlist?list=PL5VlxT4gkOFCJrO44rXkUuMfbL9PZarWK)

Step one - watch this video to set up your machine: https://www.youtube.com/watch?v=Li9uQvXEWDk&list=PL5VlxT4gkOFCJrO44rXkUuMfbL9PZarWK&index=1

Step two - watch this video to install the hedera-sdk-py: https://www.youtube.com/watch?v=I_eQiAeXyts&list=PL5VlxT4gkOFCJrO44rXkUuMfbL9PZarWK&index=2

Step three - Clone the repo in your development directory

Step four - Create a new virtual environment

You should be up to speed :)


