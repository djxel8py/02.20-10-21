import setuptools

setuptools.setup()